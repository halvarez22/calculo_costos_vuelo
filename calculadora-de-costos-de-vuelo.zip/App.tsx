

import React, { useState, useEffect } from 'react';
import { INITIAL_AIRCRAFT_CATALOG, INITIAL_AIRPORT_CATALOG, INITIAL_GLOBAL_COST_PARAMETERS, INITIAL_TAX_CATALOG, INITIAL_PILOT_CATALOG, INITIAL_MAINTENANCE_CATALOG } from './constants';
import { FormData, CalculationBreakdown, Aircraft, Airport, GlobalCostParameters, AirportTax, Pilot, MaintenanceProgram } from './types';
import { calculateFlightCosts, parseFlightData } from './lib/utils';
import { ResultCard } from './components/ResultCard';
import { PlaneIcon } from './components/icons/PlaneIcon';
import { CalculatorIcon } from './components/icons/CalculatorIcon';
import { CostBreakdownModal } from './components/CostBreakdownModal';
import { Sidebar } from './components/Sidebar';
import { ClipboardDataIcon } from './components/icons/ClipboardDataIcon';

const App: React.FC = () => {
  // Catalogs state
  const [aircrafts, setAircrafts] = useState<Aircraft[]>(INITIAL_AIRCRAFT_CATALOG);
  const [airports, setAirports] = useState<Airport[]>(INITIAL_AIRPORT_CATALOG);
  const [globalParams, setGlobalParams] = useState<GlobalCostParameters>(INITIAL_GLOBAL_COST_PARAMETERS);
  const [taxes, setTaxes] = useState<AirportTax[]>(INITIAL_TAX_CATALOG);
  const [pilots, setPilots] = useState<Pilot[]>(INITIAL_PILOT_CATALOG);
  const [maintenancePrograms, setMaintenancePrograms] = useState<MaintenanceProgram[]>(INITIAL_MAINTENANCE_CATALOG);

  // Form and results state
  const [formData, setFormData] = useState<FormData>({
    aircraftId: INITIAL_AIRCRAFT_CATALOG[0]?.id || '',
    pilotInCommandId: INITIAL_PILOT_CATALOG[0]?.id || '',
    firstOfficerId: INITIAL_PILOT_CATALOG[2]?.id || '',
    flightDataCsv: '',
  });
  
  const [results, setResults] = useState<CalculationBreakdown | null>(null);
  const [isCalculated, setIsCalculated] = useState<boolean>(false);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Reset form selectors if the selected items are removed from the catalog
    if (!aircrafts.find(a => a.id === formData.aircraftId)) {
      setFormData(prev => ({ ...prev, aircraftId: aircrafts[0]?.id || '' }));
    }
    if (!pilots.find(p => p.id === formData.pilotInCommandId)) {
        setFormData(prev => ({ ...prev, pilotInCommandId: pilots[0]?.id || '' }));
    }
    if (!pilots.find(p => p.id === formData.firstOfficerId)) {
        const availablePilots = pilots.filter(p => p.id !== formData.pilotInCommandId);
        setFormData(prev => ({ ...prev, firstOfficerId: availablePilots[0]?.id || '' }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aircrafts, pilots]);

  const handleInputChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    setFormData(prev => {
        const newState = { ...prev, [name]: value };
        // Prevent selecting the same pilot for both roles
        if (name === 'pilotInCommandId' && value === newState.firstOfficerId) {
            const otherPilot = pilots.find(p => p.id !== value);
            newState.firstOfficerId = otherPilot?.id || '';
        }
        if (name === 'firstOfficerId' && value === newState.pilotInCommandId) {
            const otherPilot = pilots.find(p => p.id !== value);
            newState.pilotInCommandId = otherPilot?.id || '';
        }
        return newState;
    });

    // Auto-select aircraft from CSV data
    if (name === 'flightDataCsv') {
        try {
            const { callsign } = parseFlightData(value);
            if (callsign) {
                const matchedAircraft = aircrafts.find(a => a.registration.toUpperCase() === callsign.toUpperCase());
                if (matchedAircraft) {
                    setFormData(prev => ({...prev, aircraftId: matchedAircraft.id, flightDataCsv: value}));
                }
            }
        } catch (e: any) {
             setError(e.message);
             return;
        }
    }

    setError(null);
    setResults(null);
    setIsCalculated(false);
  };

  const handleCalculate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!formData.flightDataCsv.trim()) {
      setError("Por favor, pegue los datos de seguimiento del vuelo.");
      return;
    }
     if (formData.pilotInCommandId === formData.firstOfficerId) {
      setError("El Piloto y el Primer Oficial no pueden ser la misma persona.");
      return;
    }
    setError(null);
    setIsCalculated(false);

    try {
        const newResults = calculateFlightCosts(formData, aircrafts, airports, pilots, globalParams, taxes, maintenancePrograms);
        if (!newResults) {
            setError("No se pudo calcular. Verifique los datos del vuelo y que la aeronave seleccionada exista en el catálogo.");
            return;
        }
        setResults(newResults);
        setTimeout(() => setIsCalculated(true), 100);
    } catch(e: any) {
        setError(`Error al procesar los datos: ${e.message}`);
    }
  };

  const formatCurrency = (value: number) => {
    return value.toLocaleString('es-MX', {
      style: 'currency',
      currency: 'USD',
    });
  };
    
  const selectablePilots = (exclude?: string) =>
    pilots.filter(p => p.id !== exclude).map(pilot => (
      <option key={pilot.id} value={pilot.id}>
        {pilot.name}
      </option>
    ));

  return (
    <>
      <div className="min-h-screen bg-slate-900 text-white font-sans">
        <div className="grid grid-cols-1 xl:grid-cols-[1fr_450px] gap-0 min-h-screen">
          
          {/* Main Content */}
          <main className="flex flex-col items-center justify-center p-4 xl:p-8 bg-slate-800/50">
            <div className="w-full max-w-4xl mx-auto">
              <header className="text-center mb-8">
                <div className="inline-block bg-sky-500/10 p-4 rounded-full mb-4 border border-sky-500/20">
                  <PlaneIcon className="w-12 h-12 text-sky-400" />
                </div>
                <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight">
                  Análisis de Costos de Vuelo
                </h1>
                <p className="text-slate-400 mt-2 text-lg">
                  Calcule los costos exactos de un vuelo a partir de sus datos de seguimiento.
                </p>
              </header>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-slate-900/70 p-8 rounded-2xl shadow-2xl border border-slate-700 backdrop-blur-sm">
                  <form onSubmit={handleCalculate} className="space-y-6">
                    <div className="relative">
                       <label htmlFor="flightDataCsv" className="block text-sm font-medium text-slate-300 mb-2">
                         Datos de Seguimiento del Vuelo (CSV)
                       </label>
                       <ClipboardDataIcon className="absolute top-11 left-3 w-5 h-5 text-slate-400" />
                       <textarea
                         id="flightDataCsv"
                         name="flightDataCsv"
                         value={formData.flightDataCsv}
                         onChange={handleInputChange}
                         rows={6}
                         className="w-full bg-slate-800 border border-slate-600 rounded-lg py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition font-mono text-xs"
                         placeholder='Pegue aquí los datos del archivo CSV de Flightradar24...'
                       />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-6">
                      <div className="sm:col-span-2">
                        <label htmlFor="aircraftId" className="block text-sm font-medium text-slate-300 mb-2">Aeronave (Auto-seleccionada por Matrícula)</label>
                        <select id="aircraftId" name="aircraftId" value={formData.aircraftId} onChange={handleInputChange} className="w-full bg-slate-800 border border-slate-600 rounded-lg py-3 px-4 text-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition">
                          {aircrafts.map(ac => <option key={ac.id} value={ac.id}>{`${ac.brand} ${ac.model} (${ac.registration})`}</option>)}
                        </select>
                      </div>
                      <div>
                        <label htmlFor="pilotInCommandId" className="block text-sm font-medium text-slate-300 mb-2">Piloto al Mando</label>
                        <select id="pilotInCommandId" name="pilotInCommandId" value={formData.pilotInCommandId} onChange={handleInputChange} className="w-full bg-slate-800 border border-slate-600 rounded-lg py-3 px-4 text-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition">
                          {selectablePilots(formData.firstOfficerId)}
                        </select>
                      </div>
                       <div>
                        <label htmlFor="firstOfficerId" className="block text-sm font-medium text-slate-300 mb-2">Primer Oficial</label>
                        <select id="firstOfficerId" name="firstOfficerId" value={formData.firstOfficerId} onChange={handleInputChange} className="w-full bg-slate-800 border border-slate-600 rounded-lg py-3 px-4 text-white focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition">
                          {selectablePilots(formData.pilotInCommandId)}
                        </select>
                      </div>
                    </div>

                    <button type="submit" className="w-full flex items-center justify-center bg-sky-600 hover:bg-sky-500 text-white font-bold py-3 px-4 rounded-lg shadow-lg transition-transform transform hover:scale-105">
                      <CalculatorIcon className="w-5 h-5 mr-2" />
                      Calcular Costos
                    </button>
                    {error && <p className="text-center text-red-400 mt-4">{error}</p>}
                  </form>
                </div>

                <div className="bg-slate-900/70 p-8 rounded-2xl shadow-2xl border border-slate-700 backdrop-blur-sm flex flex-col justify-center">
                  <h2 className="text-2xl font-bold text-white mb-6 text-center">Resultados del Cálculo</h2>
                  {results ? (
                    <div className={`space-y-6 transition-all duration-500 ease-out ${isCalculated ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
                      <ResultCard
                        label="Costo Total del Viaje"
                        value={formatCurrency(results.totalCost)}
                        description="Clic para ver desglose detallado."
                        onClick={() => setIsModalOpen(true)}
                      />
                      <ResultCard
                        label="Costo por Hora de Vuelo"
                        value={formatCurrency(results.costPerHour)}
                        description={`Basado en un vuelo real de ${results.flightHours.toFixed(2)} horas.`}
                        onClick={() => setIsModalOpen(true)}
                      />
                    </div>
                  ) : (
                    <div className="text-center text-slate-400 py-10">
                      <p>{error ? 'Por favor corrija el error.' : 'Pegue los datos del vuelo y haga clic en \'Calcular\' para ver los resultados.'}</p>
                    </div>
                  )}
                </div>
              </div>
              <footer className="text-center text-slate-500 mt-12 text-sm">
                <p>Creado por un experto en React y Gemini.</p>
              </footer>
            </div>
          </main>
          
          {/* Sidebar */}
          <Sidebar 
            aircrafts={aircrafts}
            setAircrafts={setAircrafts}
            airports={airports}
            setAirports={setAirports}
            pilots={pilots}
            setPilots={setPilots}
            globalParams={globalParams}
            setGlobalParams={setGlobalParams}
            taxes={taxes}
            setTaxes={setTaxes}
            maintenancePrograms={maintenancePrograms}
            setMaintenancePrograms={setMaintenancePrograms}
          />

        </div>
      </div>
      {results && (
        <CostBreakdownModal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          breakdown={results}
          formatCurrency={formatCurrency}
        />
      )}
    </>
  );
};

export default App;